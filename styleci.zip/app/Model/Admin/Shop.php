<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class Shop extends Model
{
    protected $guarded = [];
}
