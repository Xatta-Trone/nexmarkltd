<?php $__env->startSection('page_title','Edit'); ?>

<?php $__env->startSection('extra_css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Edit Category
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-success pull-right ">List</a>
        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-success pull-right ">Add</a>


    </h1>
    
</section>

<!-- Main content -->
<section class="content">
    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- general form elements -->
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Edit category</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form" method="POST" action="<?php echo e(route('categories.update',$category->id)); ?>">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="box-body">
                <div class="form-group">
                    <label for="name">Category Name</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter categroy name"
                        value="<?php echo e($category->name); ?>" autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="slug">Category Slug</label>
                    <input type="text" class="form-control" value="<?php echo e($category->slug); ?>" name="slug" id="slug"
                        placeholder="Enter categroy slug">
                </div>

                <div class="form-group">
                    <label>Parent category</label>
                    <select class="form-control" name="parent_category">
                        <option value="">Select one</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($cat->id); ?> <?php echo e(($cat->id == $category->parent_category) ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <select class="form-control" name="status">
                        <option value="1" <?php echo e($category->status == 1 ? 'selected' : ''); ?>>Active</option>
                        <option value="0" <?php echo e($category->status == 0 ? 'selected' : ''); ?>>Inactive</option>

                    </select>
                </div>



            </div>
            <!-- /.box-body -->

            <div class="box-footer">
                <button type="submit" class="btn btn-primary"
                    onClick="this.form.submit(); this.disabled=true; this.innerText='Submitting....'; ">Submit</button>
            </div>
        </form>
    </div>
    <!-- /.box -->



</section>
<!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>




<script>
    let parent = document.getElementById('name')

    parent.addEventListener('keyup',makeslug)

    function makeslug(){
        let slugField = document.getElementById('slug')

        let slug = convertToSlug(parent.value);

        slugField.value = slug;
        console.log();
    }

    function convertToSlug(Text)
    {
        return Text
            .toLowerCase()
            .replace(/[^\w ]+/g,'')
            .replace(/ +/g,'-')
            ;
    }


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\nexmarkltd\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>